"""Asosiy buyruq: python scripts/run_all.py"""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.pipeline import run_pipeline

if __name__ == "__main__":
    result = run_pipeline()
    print("\n✅ Dataset Builder tugadi. Meta:", result["binary"])

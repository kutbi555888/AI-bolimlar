"""Yaratilgan fayllarning yaxlitligini va qayta ochilishini tekshiradi."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.io_utils import read_jsonl
from src.tokenizer_bpe import SimpleByteBPE
from src.dataset_builder import read_uint16_le

def main():
    tokenizer = SimpleByteBPE.from_file(ROOT / "tokenizer/tokenizer.json")
    sample = "O‘zbekcha hikoya: daraxt va bahor!"
    assert tokenizer.decode(tokenizer.encode(sample)) == sample
    train = read_jsonl(ROOT / "data/splits/train.jsonl")
    val = read_jsonl(ROOT / "data/splits/val.jsonl")
    assert {r["id"] for r in train}.isdisjoint({r["id"] for r in val})
    for name in ("train", "val"):
        ids = read_uint16_le(ROOT / f"data/binaries/{name}.bin")
        assert ids and max(ids) < tokenizer.vocab_size
    print("Barcha tekshiruvlar muvaffaqiyatli yakunlandi.")

if __name__ == "__main__":
    main()

"""Pipeline bo‘limlarining standart unittest bilan sinovlari."""
import tempfile
import unittest
from pathlib import Path
from src.cleaning import normalize_text
from src.filtering import filter_rows
from src.deduplication import dedup_rows
from src.pii import redact_pii
from src.tokenizer_bpe import SimpleByteBPE
from src.pipeline import run_pipeline
from src.dataset_builder import read_uint16_le
from src.io_utils import read_jsonl
from src.config import load_config


class TestPipeline(unittest.TestCase):
    def test_uzbek_cleaning(self):
        self.assertEqual(normalize_text("  O'zbekcha   so'z  "), "O‘zbekcha so‘z")

    def test_filtering(self):
        cfg = load_config()["filtr"]
        good = {"id":"ok","til":"uz","matn":"Bugun kichik qishloqda bolalar ko‘chat ekishdi. Ular yerga suv quyib, o‘simlikni kuzatishdi. Ertasi kuni ko‘chat yana yashil ekanini ko‘rib, quvonishdi."}
        bad = {"id":"bad","til":"uz","matn":"Juda qisqa."}
        kept, rejected, why = filter_rows([good,bad], cfg)
        self.assertEqual(len(kept), 1)
        self.assertEqual(len(rejected), 1)

    def test_dedup(self):
        txt = "Qishloq maktabida bolalar kitoblarni yig‘ishdi va birgalikda kutubxonaga borishdi. Ular ertasi kuni yana qaytib, yangi bilimlarni bir-biriga tushuntirishdi."
        rows = [{"id":"a","matn":txt},{"id":"b","matn":txt}]
        kept, removed, counts = dedup_rows(rows)
        self.assertEqual((len(kept),len(removed)),(1,1))
        self.assertEqual(counts["aniq_dublikat"],1)

    def test_pii(self):
        clean, counts = redact_pii("Yozing: test@example.com yoki +998 90 123 45 67")
        self.assertIn("[EMAIL]",clean)
        self.assertIn("[TELEFON]",clean)
        self.assertEqual(counts["email"],1)
        self.assertEqual(counts["telefon"],1)

    def test_byte_bpe_roundtrip(self):
        text = "O‘zbekcha hikoya: qaldirg‘och uchib keldi!"
        tk = SimpleByteBPE.train([text]*3, vocab_size=300)
        self.assertEqual(tk.decode(tk.encode(text,add_eos=True)),text)

    def test_full_pipeline_in_tempdir(self):
        with tempfile.TemporaryDirectory() as work:
            root = Path(work)
            result = run_pipeline(workspace=root, verbose=False)
            train = read_jsonl(root / "data/splits/train.jsonl")
            val = read_jsonl(root / "data/splits/val.jsonl")
            self.assertTrue({r["id"] for r in train}.isdisjoint({r["id"] for r in val}))
            self.assertEqual(result["binary"]["train_hikoyalar"],len(train))
            tokens = read_uint16_le(root / "data/binaries/train.bin")
            self.assertEqual(len(tokens),result["binary"]["train_tokenlar"])
            self.assertEqual(tokens.count(256),len(train))
            self.assertTrue((root / "results/stats_report.md").exists())
            self.assertEqual(len(read_jsonl(root / "data/raw/hikoyalar_raw.jsonl")),94)


if __name__ == "__main__":
    unittest.main()

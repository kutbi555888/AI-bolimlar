"""Dataset Builder: tokenlashtirilgan train.bin va val.bin fayllarini yaratish."""
from __future__ import annotations
from array import array
from hashlib import sha256
from pathlib import Path
import sys
from .io_utils import write_json
from .tokenizer_bpe import EOS_ID, SimpleByteBPE


def write_uint16_le(path: Path, ids: list[int]) -> str:
    """IDlarni uint16 little-endian binary formatda saqlaydi."""
    if any(not 0 <= i <= 65535 for i in ids):
        raise ValueError("uint16 formatga sig'maydigan token ID bor")
    data = array("H", ids)
    if data.itemsize != 2:
        raise RuntimeError("uint16 array ushbu platformada qo'llanmaydi")
    if sys.byteorder != "little":
        data.byteswap()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data.tobytes())
    return sha256(path.read_bytes()).hexdigest()


def read_uint16_le(path: Path) -> list[int]:
    """Binary faylni tekshirish uchun uint16 little-endian shaklda o‘qiydi."""
    raw = Path(path).read_bytes()
    if len(raw) % 2:
        raise ValueError("Binary faylda baytlar soni juft emas")
    values = array("H")
    values.frombytes(raw)
    if sys.byteorder != "little":
        values.byteswap()
    return values.tolist()


def build_dataset(train_rows: list[dict], val_rows: list[dict], tokenizer: SimpleByteBPE, output_dir: Path) -> dict:
    """Har hikoya orasiga EOS qo‘shib train/val binarlarini yaratadi."""
    if not train_rows or not val_rows:
        raise ValueError("Train va validation bo'sh bo'lishi mumkin emas")
    directory = Path(output_dir)
    train_ids, val_ids = [], []
    for rows, output in ((train_rows, train_ids), (val_rows, val_ids)):
        for row in rows:
            output.extend(tokenizer.encode(row["matn"], add_eos=True))
    if not train_ids or not val_ids:
        raise ValueError("Binariga yoziladigan token topilmadi")
    train_hash = write_uint16_le(directory / "train.bin", train_ids)
    val_hash = write_uint16_le(directory / "val.bin", val_ids)
    summary = {
        "format": "uint16_le",
        "tokenizer_format": "oz_bpe_byte_v1",
        "vocab_size": tokenizer.vocab_size,
        "eos_token_id": EOS_ID,
        "train_hikoyalar": len(train_rows),
        "val_hikoyalar": len(val_rows),
        "train_tokenlar": len(train_ids),
        "val_tokenlar": len(val_ids),
        "train_sha256": train_hash,
        "val_sha256": val_hash,
        "izoh": "Hikoya chegarasi <eos>. Tokenizer TRAIN dagi matnlarda o'qitilgan.",
    }
    write_json(directory / "meta.json", summary)
    return summary

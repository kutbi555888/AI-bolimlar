"""Barcha bosqichlarni tartib bilan ishlatadigan yagona pipeline."""
from __future__ import annotations
from pathlib import Path
from .config import ROOT, load_config
from .fetch import get_dataset
from .cleaning import clean_rows
from .filtering import filter_rows
from .deduplication import dedup_rows
from .pii import scrub_rows
from .split import split_rows
from .stats import describe_rows, stats_markdown
from .tokenizer_bpe import SimpleByteBPE
from .dataset_builder import build_dataset
from .io_utils import read_jsonl, write_jsonl, write_json


def run_pipeline(workspace: Path | None = None, config_path: Path | None = None, verbose: bool = True) -> dict:
    """Clean clone dan natijagacha barcha qadamlarni bajaradi.

    workspace boshqa path bo‘lishi mumkin; testlarda vaqtinchalik papka.
    Datasetning ASL manbasi doim repo ichidagi data/source dan olinadi.
    """
    root = Path(workspace) if workspace else ROOT
    cfg = load_config(config_path)
    def destination(key):
        return root / cfg["natija"][key]
    processed, splits = destination("processed"), destination("splits")
    binary, reports = destination("binary"), destination("katalog")
    source = ROOT / cfg["manba"]["lokal_fayl"]
    raw = root / cfg["manba"]["raw_fayl"]

    # 0. Manba datasetni olish (internet shart emas).
    fetch_stats = get_dataset(source, raw)
    raw_rows = read_jsonl(raw)
    if verbose: print(f"0. Manba olindi: {len(raw_rows)} hikoya")

    # 1. Cleaning: matnni normallashtirish.
    cleaned = clean_rows(raw_rows)
    write_jsonl(processed / "01_cleaned.jsonl", cleaned)
    if verbose: print(f"1. Cleaning: {len(cleaned)} hikoya")

    # 2. Filtering: keraksiz matnlarni ajratish.
    filtered, rejected, filter_reasons = filter_rows(cleaned, cfg["filtr"])
    write_jsonl(processed / "02_filtered.jsonl", filtered)
    write_jsonl(reports / "filtered_out.jsonl", rejected)
    if verbose: print(f"2. Filtering: {len(filtered)} qoldi, {len(rejected)} rad")

    # 3. Deduplication: aniq va yaqin dublikatni o‘chirish.
    unique, duplicates, dup_counts = dedup_rows(
        filtered, n=cfg["dedup"]["shingle_n"], threshold=cfg["dedup"]["jaccard_chegara"]
    )
    write_jsonl(processed / "03_deduplicated.jsonl", unique)
    write_jsonl(reports / "duplicates_out.jsonl", duplicates)
    if verbose: print(f"3. Dedup: {len(unique)} qoldi, {len(duplicates)} dublikat")

    # 4. PII: manzil va telefon namunalari kabi ma'lumotlarni yashirish.
    safe, pii_counts = scrub_rows(unique)
    write_jsonl(processed / "04_pii_safe.jsonl", safe)
    if verbose: print(f"4. PII scrub: {pii_counts}")

    # 5. Data stats va TRAIN/VAL split.
    train, val = split_rows(safe, cfg["split"]["validation_ulushi"], cfg["loyiha"]["seed"])
    write_jsonl(splits / "train.jsonl", train)
    write_jsonl(splits / "val.jsonl", val)
    if verbose: print(f"5. Split: {len(train)} train, {len(val)} validation")

    summary = {
        "loyiha": cfg["loyiha"]["nom"],
        "dataset_manzili": str(source.relative_to(ROOT)),
        "litsenziya_izohi": "DATASET_README.md ni o'qing (CC0 huquqlar mavjud bo'lgan darajada)",
        "manba_sha256": fetch_stats["sha256"],
        "sonlar": {"manba": len(raw_rows), "cleaning": len(cleaned), "filtering": len(filtered), "deduplication": len(unique), "pii": len(safe), "train": len(train), "validation": len(val)},
        "rad_sabablari": filter_reasons,
        "dublikat_turlari": dup_counts,
        "pii_topilmalar": pii_counts,
        "umumiy_statistika": describe_rows(safe),
        "train_statistika": describe_rows(train),
        "val_statistika": describe_rows(val),
    }
    write_json(reports / "stats_report.json", summary)
    reports.mkdir(parents=True, exist_ok=True)
    (reports / "stats_report.md").write_text(stats_markdown(summary), encoding="utf-8")
    if verbose: print("5. Statistika hisobotlari saqlandi")

    # 6. Tokenizer: faqat training matnlaridan BPE o‘rganiladi.
    tkcfg = cfg["tokenizer"]
    tokenizer = SimpleByteBPE.train(
        [r["matn"] for r in train],
        vocab_size=int(tkcfg["vocab_size"]),
        min_frequency=int(tkcfg["min_frequency"])
    )
    tkpath = root / cfg["natija"]["tokenizer_fayl"]
    tokenizer.save(tkpath)
    if verbose: print(f"6. Tokenizer: {tokenizer.vocab_size} token")

    # 7. Dataset Builder: little-endian uint16 token IDlar.
    built = build_dataset(train, val, tokenizer, binary)
    if verbose: print(f"7. Dataset Builder: train={built['train_tokenlar']}, val={built['val_tokenlar']} token")
    return {"stats": summary, "binary": built, "tokenizer": str(tkpath)}

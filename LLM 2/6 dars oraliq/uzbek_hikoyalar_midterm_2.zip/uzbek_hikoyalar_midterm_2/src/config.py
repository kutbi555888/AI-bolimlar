"""data.yaml konfiguratsiyasini o‘qish va muhim qiymatlarni tekshirish."""
from __future__ import annotations
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[1]


def load_config(config_path: Path | None = None) -> dict:
    """YAMLni o‘qib, kerakli bo‘limlar borligini tekshiradi."""
    path = Path(config_path) if config_path else ROOT / "configs/data.yaml"
    with path.open("r", encoding="utf-8") as f:
        config = yaml.safe_load(f)
    if not isinstance(config, dict):
        raise ValueError("Konfiguratsiya YAML obyekt bo'lishi kerak")
    for key in ("loyiha", "manba", "filtr", "dedup", "split", "tokenizer", "natija"):
        if key not in config:
            raise ValueError(f"YAML bo'limi yo'q: {key}")
    if not 0 < float(config["split"]["validation_ulushi"]) < 1:
        raise ValueError("validation_ulushi 0 va 1 orasida bo'lishi kerak")
    vocab = int(config["tokenizer"]["vocab_size"])
    if not 257 <= vocab <= 65535:
        raise ValueError("Byte BPE uchun vocab_size 257..65535 bo'lishi kerak")
    return config

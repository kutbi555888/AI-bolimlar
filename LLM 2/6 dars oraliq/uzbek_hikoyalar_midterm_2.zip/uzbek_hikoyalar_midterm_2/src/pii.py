"""4-bosqich: shaxsga oid ma'lumotlarning sodda himoyaviy filtratsiyasi."""
from __future__ import annotations
import re
from collections import Counter

PATTERNS = [
    ("email", re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"), "[EMAIL]"),
    ("telefon", re.compile(r"(?<!\w)(?:\+?998[\s-]?)?(?:\(?\d{2}\)?[\s-]?)\d{3}[\s-]?\d{2}[\s-]?\d{2}(?!\d)"), "[TELEFON]"),
]


def redact_pii(text: str) -> tuple[str, dict]:
    """Email va telefon raqamlarini maxsus belgilarga almashtiradi.

    Bu faqat demonstratsion regex: ism, manzil va murakkab PII to‘liq ushlanmaydi.
    """
    counts = Counter()
    for label, regex, replacement in PATTERNS:
        text, n = regex.subn(replacement, text)
        counts[label] += n
    return text, dict(counts)


def scrub_rows(rows: list[dict]) -> tuple[list[dict], dict]:
    """Hikoyalarni PII dan tozalaydi, topilgan sonlar bo‘yicha hisobot qaytaradi."""
    totals = Counter()
    result = []
    for row in rows:
        text, counts = redact_pii(row["matn"])
        totals.update(counts)
        item = dict(row)
        item["matn"] = text
        result.append(item)
    return result, dict(totals)

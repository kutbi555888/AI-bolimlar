"""0-bosqich: dataset manbasini olish (offline ham ishlaydi)."""
from __future__ import annotations
from hashlib import sha256
from pathlib import Path
import shutil
from .io_utils import read_jsonl


def get_dataset(source_path: Path, output_path: Path) -> dict:
    """Repo bilan kelgan hikoyalarni xom ma'lumot katalogiga ko‘chiradi.

    Nega yuklash emas? Dataset to‘liq repo ichiga kiritilgan, shuning uchun
    internet bo‘lmasa ham clean clone dan qayta tiklash mumkin.
    """
    source_path, output_path = Path(source_path), Path(output_path)
    if not source_path.exists():
        raise FileNotFoundError(f"Manba dataset mavjud emas: {source_path}")
    if not read_jsonl(source_path):
        raise ValueError("Manba dataset bo'sh")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if source_path.resolve() != output_path.resolve():
        shutil.copyfile(source_path, output_path)
    digest = sha256(output_path.read_bytes()).hexdigest()
    return {"yozuvlar": len(read_jsonl(output_path)), "sha256": digest, "rejim": "offline_bundled_copy"}

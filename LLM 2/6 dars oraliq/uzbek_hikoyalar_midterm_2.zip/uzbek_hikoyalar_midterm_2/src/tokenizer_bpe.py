"""6-bosqich: oddiy, kutubxonasiz, UTF-8 byte-level BPE tokenizer.

Bu o‘quv tokenizeridir: Hugging Face `tokenizers` JSON formati bilan
mos emas. Har doim src/tokenizer_bpe.py orqali ochish kerak.
"""
from __future__ import annotations
from collections import Counter
from pathlib import Path
import json

EOS_ID = 256  # 0..255 = bitta bayt, 256 = hikoyaning tugash belgisi.


def merge_pair(ids: list[int], a: int, b: int, new: int) -> list[int]:
    """Berilgan token juftini chapdan o‘ngga, ustma-ust tushirmasdan almashtiradi."""
    result = []
    i = 0
    while i < len(ids):
        if i + 1 < len(ids) and ids[i] == a and ids[i + 1] == b:
            result.append(new)
            i += 2
        else:
            result.append(ids[i])
            i += 1
    return result


class SimpleByteBPE:
    """UTF-8 baytlari ustida eng ko‘p uchraydigan juftlarni birlashtiradi."""

    def __init__(self, merges: list[list[int]] | None = None, pieces: list[str | None] | None = None):
        self.merges = merges if merges is not None else []
        self.pieces = pieces if pieces is not None else [bytes([i]).hex() for i in range(256)] + [None]

    @classmethod
    def train(cls, texts: list[str], vocab_size: int = 512, min_frequency: int = 2):
        """Muhim: tokenizer faqat TRAIN hikoyalarida o‘rgatiladi."""
        if not texts:
            raise ValueError("Tokenizer uchun training matnlari kerak")
        if not 257 <= vocab_size <= 65535:
            raise ValueError("vocab_size 257..65535 bo'lishi kerak")
        if min_frequency < 2:
            raise ValueError("min_frequency >= 2 bo'lishi kerak")
        sequences = [list(t.encode("utf-8")) for t in texts]
        pieces = [bytes([i]).hex() for i in range(256)] + [None]
        merges = []
        for next_id in range(257, vocab_size):
            frequencies = Counter(
                pair
                for seq in sequences
                for pair in zip(seq, seq[1:])
            )
            if not frequencies:
                break
            # Teng sonli juftlar uchun ham har safar bir xil natija.
            pair, freq = min(
                frequencies.items(),
                key=lambda item: (-item[1], item[0])
            )
            if freq < min_frequency:
                break
            a, b = pair
            merges.append([a, b, next_id])
            pieces.append((bytes.fromhex(pieces[a]) + bytes.fromhex(pieces[b])).hex())
            sequences = [merge_pair(seq, a, b, next_id) for seq in sequences]
        return cls(merges, pieces)

    @property
    def vocab_size(self) -> int:
        return len(self.pieces)

    def encode(self, text: str, add_eos: bool = False) -> list[int]:
        """Matnni UTF-8 baytga, keyin ketma-ket BPE mergega aylantiradi."""
        ids = list(text.encode("utf-8"))
        for a, b, new in self.merges:
            ids = merge_pair(ids, a, b, new)
        if add_eos:
            ids.append(EOS_ID)
        return ids

    def decode(self, ids: list[int], skip_special_tokens: bool = True) -> str:
        """Tokenlarni birlashtirib asl UTF-8 matnni qayta tiklaydi."""
        parts = []
        for idx in ids:
            if idx == EOS_ID:
                if skip_special_tokens:
                    continue
                parts.append(b"<eos>")
            elif 0 <= idx < len(self.pieces) and self.pieces[idx] is not None:
                parts.append(bytes.fromhex(self.pieces[idx]))
            else:
                raise ValueError(f"Noto'g'ri token ID: {idx}")
        return b"".join(parts).decode("utf-8")

    def save(self, path: Path) -> None:
        """Model merges va token baytlarini o‘zimizning JSON formatida saqlaydi."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "format": "oz_bpe_byte_v1",
            "izoh": "Maxsus o'quv formati; Hugging Face tokenizer.json bilan mos emas.",
            "eos_token": "<eos>",
            "eos_token_id": EOS_ID,
            "vocab_size": self.vocab_size,
            "pieces_hex": self.pieces,
            "merges": self.merges,
        }
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def from_file(cls, path: Path):
        """Oldin o‘rgatilgan tokenizer faylini qayta yuklaydi."""
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        if data.get("format") != "oz_bpe_byte_v1":
            raise ValueError("Tokenizer formati mos emas")
        t = cls(data["merges"], data["pieces_hex"])
        if len(t.pieces) != data["vocab_size"]:
            raise ValueError("Tokenizer ID ro'yxati buzilgan")
        return t

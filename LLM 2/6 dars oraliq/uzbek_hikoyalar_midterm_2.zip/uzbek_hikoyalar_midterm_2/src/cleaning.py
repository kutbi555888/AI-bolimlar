"""1-bosqich: matnni bir xil toza shaklga keltirish."""
from __future__ import annotations
import re
import unicodedata


def normalize_text(value: str) -> str:
    """Unicode NFC, o‘zbekcha tutuq, ortiqcha bo‘shliq va boshqaruv belgilarini normallashtiradi."""
    text = unicodedata.normalize("NFC", str(value))
    text = text.replace("\ufeff", "").replace("\u200b", "")
    # Barcha apostroflarni bir xil o‘zbekcha ‘ ko‘rinishiga keltiramiz.
    text = re.sub(r"(?<=[A-Za-z])['’ʻʼ](?=[A-Za-z])", "‘", text)
    text = re.sub(r"[\t\r\n]+", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def clean_rows(rows: list[dict]) -> list[dict]:
    """Har bir yozuvning sarlavha va hikoya matnini tozalaydi."""
    result = []
    for row in rows:
        item = dict(row)
        item["sarlavha"] = normalize_text(row.get("sarlavha", ""))
        item["matn"] = normalize_text(row.get("matn", ""))
        item["til"] = normalize_text(row.get("til", ""))
        result.append(item)
    return result

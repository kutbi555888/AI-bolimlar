"""2-bosqich: sifatsiz, haddan tashqari qisqa yoki noto‘g‘ri yozuvlarni ajratish."""
from __future__ import annotations
import re
from collections import Counter

URL = re.compile(r"(?:https?://|www\.)\S+", flags=re.IGNORECASE)


def filter_rows(rows: list[dict], cfg: dict) -> tuple[list[dict], list[dict], dict]:
    """Faqat shartlarga mos hikoyalar qoladi, qolganlar sabab bilan ajratiladi."""
    kept, rejected, reasons = [], [], Counter()
    for row in rows:
        text = row.get("matn", "")
        words = text.split()
        reason = None
        if row.get("til", "").lower() != cfg["kerakli_til"]:
            reason = "til_mos_emas"
        elif int(cfg["min_soz"]) > len(words):
            reason = "juda_qisqa"
        elif len(words) > int(cfg["max_soz"]):
            reason = "juda_uzun"
        elif len(text) < int(cfg["min_belgi"]):
            reason = "belgi_kam"
        elif cfg.get("url_borlarini_olib_tashlash", True) and URL.search(text):
            reason = "reklama_yoki_url"
        elif sum(ch.isalpha() for ch in text) / max(len(text), 1) < 0.55:
            reason = "harf_ulushi_past"
        if reason:
            item = dict(row)
            item["rad_sababi"] = reason
            rejected.append(item)
            reasons[reason] += 1
        else:
            kept.append(row)
    return kept, rejected, dict(reasons)

"""3-bosqich: aynan bir xil va juda o‘xshash hikoyalarni olib tashlash."""
from __future__ import annotations
import hashlib
import re


def normalized_key(text: str) -> str:
    """Registr va tinish belgilarining farqini chetlab o‘tuvchi kalit."""
    return " ".join(re.findall(r"\w+", text.casefold(), flags=re.UNICODE))


def shingles(text: str, n: int = 4) -> set[tuple[str, ...]]:
    """N ta ketma-ket so‘zlardan tuzilgan to‘plam (word-shingles)."""
    words = normalized_key(text).split()
    if len(words) < n:
        return {tuple(words)}
    return {tuple(words[i:i+n]) for i in range(len(words)-n+1)}


def jaccard(a: set, b: set) -> float:
    """Ikki to‘plam kesishmasi / birlashmasi; 1 = bir xil."""
    return len(a & b) / len(a | b) if a or b else 1.0


def dedup_rows(rows: list[dict], n: int = 4, threshold: float = 0.78) -> tuple[list[dict], list[dict], dict]:
    """Kichik korpusda Jaccard bilan yaqin dublikatni topadi (O(N²)).

    Katta korpusda MinHash/LSH yaxshiroq, ammo bu loyiha uchun
    sodda va tushunarli aniq Jaccard hisoblash yetarli.
    """
    kept, dropped = [], []
    known_hashes = set()
    known_shingles = []
    counts = {"aniq_dublikat": 0, "yaqin_dublikat": 0}
    for row in rows:
        key = normalized_key(row["matn"])
        digest = hashlib.sha256(key.encode("utf-8")).hexdigest()
        if digest in known_hashes:
            reason = "aniq_dublikat"
        else:
            sh = shingles(row["matn"], n=n)
            reason = "yaqin_dublikat" if any(jaccard(sh, old) >= threshold for old in known_shingles) else None
        if reason:
            removed = dict(row)
            removed["rad_sababi"] = reason
            dropped.append(removed)
            counts[reason] += 1
        else:
            kept.append(row)
            known_hashes.add(digest)
            known_shingles.append(sh)
    return kept, dropped, counts

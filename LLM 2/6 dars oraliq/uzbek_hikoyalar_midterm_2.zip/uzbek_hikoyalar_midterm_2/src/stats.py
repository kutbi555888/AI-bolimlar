"""5-bosqich: dataset sifat va hajm ko‘rsatkichlari bo‘yicha hisobot."""
from __future__ import annotations
from collections import Counter
from statistics import mean, median
from .deduplication import normalized_key


def describe_rows(rows: list[dict]) -> dict:
    """Hikoyalar, so‘zlar, belgilar, uzunlik va tez-tez keladigan so‘zlar."""
    lengths = [len(r["matn"].split()) for r in rows]
    words = Counter()
    for row in rows:
        words.update(normalized_key(row["matn"]).split())
    return {
        "hikoyalar_soni": len(rows),
        "jami_soz": sum(lengths),
        "jami_belgi": sum(len(r["matn"]) for r in rows),
        "ortalama_soz": round(mean(lengths), 2) if lengths else 0,
        "mediana_soz": median(lengths) if lengths else 0,
        "eng_qisqa_soz": min(lengths) if lengths else 0,
        "eng_uzun_soz": max(lengths) if lengths else 0,
        "eng_kop_uchraydigan_sozlar": words.most_common(15),
    }


def stats_markdown(summary: dict) -> str:
    """O‘qish uchun qulay Markdown hisobot tayyorlaydi."""
    lines = ["# Dataset tayyorlash statistikasi", "", "| Bosqich | Hikoyalar |", "|---|---:|"]
    for key in ("manba", "cleaning", "filtering", "deduplication", "pii", "train", "validation"):
        row = summary.get("sonlar", {})
        if key in row:
            lines.append(f"| {key} | {row[key]} |")
    lines.extend(["", "## Qo‘shimcha ma'lumot", ""])
    for k, v in summary.items():
        if k != "sonlar":
            lines.append(f"- **{k}**: `{v}`")
    lines.extend(["", "**Ogohlantirish:** bu kichik o‘quv korpusi. Jiddiy LLM sifatini ta'minlamaydi."])
    return "\n".join(lines) + "\n"

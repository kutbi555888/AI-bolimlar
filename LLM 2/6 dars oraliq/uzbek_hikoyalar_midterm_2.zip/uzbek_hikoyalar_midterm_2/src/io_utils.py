"""JSONL va JSON fayllarini xavfsiz va tushunarli o‘qish-yozish yordamchilari."""
from __future__ import annotations
import json
from pathlib import Path


def read_jsonl(path: Path) -> list[dict]:
    """JSONL: har bir qatorda bittadan JSON obyekt saqlanadi."""
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Ma'lumot fayli topilmadi: {path}")
    items = []
    with path.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path} faylida {line_no}-qator noto'g'ri JSON") from exc
            if not isinstance(row, dict):
                raise ValueError(f"{line_no}-qatorda obyekt (dict) kerak")
            items.append(row)
    return items


def write_jsonl(path: Path, rows: list[dict]) -> None:
    """Ro‘yxatdagi hikoyalarni UTF-8 JSONL formatida saqlaydi."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def write_json(path: Path, obj: dict) -> None:
    """Hisobot va metadata uchun JSON fayl yaratadi."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

"""Hikoyalar darajasida deterministik train/validation ajratish."""
from __future__ import annotations
import random


def split_rows(rows: list[dict], val_ratio: float, seed: int) -> tuple[list[dict], list[dict]]:
    """Dedup va PII dan keyin train/val ajratiladi — leakage kamayadi."""
    if len(rows) < 2:
        raise ValueError("Train/val ajratish uchun kamida ikkita hikoya kerak")
    copied = list(rows)
    random.Random(seed).shuffle(copied)
    val_count = min(len(copied)-1, max(1, round(len(copied)*val_ratio)))
    val_rows = sorted(copied[:val_count], key=lambda r: r["id"])
    train_rows = sorted(copied[val_count:], key=lambda r: r["id"])
    return train_rows, val_rows

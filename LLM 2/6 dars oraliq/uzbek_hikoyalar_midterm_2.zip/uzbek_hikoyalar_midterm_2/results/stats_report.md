# Dataset tayyorlash statistikasi

| Bosqich | Hikoyalar |
|---|---:|
| manba | 94 |
| cleaning | 94 |
| filtering | 92 |
| deduplication | 90 |
| pii | 90 |
| train | 76 |
| validation | 14 |

## Qo‘shimcha ma'lumot

- **loyiha**: `uzbek_hikoyalar_midterm`
- **dataset_manzili**: `data\source\hikoyalar_manba.jsonl`
- **litsenziya_izohi**: `DATASET_README.md: CC0 huquqlar mavjud bo'lgan darajada`
- **manba_sha256**: `b97d985ecd09851f311fc81f31312cd48d6db69ad8e42613251152be4e0746a5`
- **rad_sabablari**: `{'juda_qisqa': 2}`
- **dublikat_turlari**: `{'aniq_dublikat': 1, 'yaqin_dublikat': 1}`
- **pii_topilmalar**: `{'email': 1, 'telefon': 1}`
- **umumiy_statistika**: `{'hikoyalar_soni': 90, 'jami_soz': 2764, 'jami_belgi': 21715, 'ortalama_soz': 30.71, 'mediana_soz': 30.0, 'eng_qisqa_soz': 25, 'eng_uzun_soz': 39, 'eng_kop_uchraydigan_sozlar': [('o', 85), ('ko', 63), ('u', 53), ('bir', 38), ('va', 37), ('kichik', 33), ('yo', 32), ('bo', 32), ('bilan', 32), ('qo', 24), ('kuni', 18), ('ham', 18), ('uchun', 17), ('haqida', 17), ('bolalar', 17)]}`
- **train_statistika**: `{'hikoyalar_soni': 76, 'jami_soz': 2327, 'jami_belgi': 18299, 'ortalama_soz': 30.62, 'mediana_soz': 30.0, 'eng_qisqa_soz': 25, 'eng_uzun_soz': 39, 'eng_kop_uchraydigan_sozlar': [('o', 71), ('ko', 51), ('u', 46), ('bir', 31), ('yo', 29), ('va', 27), ('kichik', 27), ('bo', 26), ('bilan', 26), ('qo', 17), ('eski', 15), ('kuni', 15), ('ham', 15), ('har', 14), ('haqida', 14)]}`
- **val_statistika**: `{'hikoyalar_soni': 14, 'jami_soz': 437, 'jami_belgi': 3416, 'ortalama_soz': 31.21, 'mediana_soz': 31.0, 'eng_qisqa_soz': 28, 'eng_uzun_soz': 36, 'eng_kop_uchraydigan_sozlar': [('o', 14), ('ko', 12), ('va', 10), ('u', 7), ('qo', 7), ('bir', 7), ('kichik', 6), ('bilan', 6), ('bo', 6), ('bolalar', 4), ('keyin', 4), ('kuni', 3), ('tog', 3), ('chiqdi', 3), ('yog', 3)]}`

**Ogohlantirish:** bu kichik o‘quv korpusi. Jiddiy LLM sifatini ta'minlamaydi.
